Something hiding in there?

-NULL, Node 6