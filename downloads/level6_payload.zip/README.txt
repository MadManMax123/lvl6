NULL has left you some help... maybe it will unlock what hides in its vault. But you must understand, NULL is a machine so it won't see something as you see it. Good luck.

git clone https://github.com/syssec-utd/pylingual
cd pylingual
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install "poetry>=2.0"
poetry lock
poetry install
poetry run pylingual -o out "[VAULT PATH]"

But as always, there are two ways to solve this node.